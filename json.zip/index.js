const { Client, GatewayIntentBits, Collection } = require('discord.js');
const path = require('path');
const fs = require('fs');
const ayarlar = require('./config.json');

// Bot istemcisini oluştur
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
  ]
});

// Komut koleksiyonu
client.commands = new Collection();

// Handlers yükle
const handlersDir = path.join(__dirname, 'handlers');
const handlerFiles = fs.readdirSync(handlersDir).filter(file => file.endsWith('.js'));

(async () => {
  for (const file of handlerFiles) {
    const handler = require(path.join(handlersDir, file));
    await handler(client);
  }

  // Discord'a giriş yap
  client.login(ayarlar.token);
})();
