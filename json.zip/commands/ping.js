const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Botun ping değerini gösterir!'),
  async execute(interaction) {
    const sent = await interaction.reply({ content: 'Ping hesaplanıyor...', fetchReply: true });
    const pingValue = sent.createdTimestamp - interaction.createdTimestamp;
    await interaction.editReply(`🏓 Pong! Gecikme: ${pingValue}ms. API Gecikmesi: ${interaction.client.ws.ping}ms`);
  },
};
