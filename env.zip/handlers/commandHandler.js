// filepath: c:\Users\MrCaniwes\Desktop\sources\bosaltyapıenv\handlers\commandHandler.js
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

module.exports = async (client) => {
  const commands = [];
  const commandsPath = path.join(__dirname, '..', 'commands');
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
  
  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    
    // Komutu koleksiyona ekle
    if ('data' in command && 'execute' in command) {
      client.commands.set(command.data.name, command);
      commands.push(command.data.toJSON());
    } else {
      console.log(`[UYARI] ${filePath} komutunda "data" veya "execute" eksik.`);
    }
  }

  // Komutları Discord API'ye kaydet
  const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
  
  try {
    console.log('Slash komutları yükleniyor...');
    
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands },
    );
    
    console.log('Slash komutları başarıyla yüklendi!');
  } catch (error) {
    console.error('Slash komut yüklemede hata:', error);
  }
};